﻿using System;
using System.IO;

namespace Entidades
{
    public static class AdministradorArchivos
    {
        public static bool Escribir(string path,string cadena)
        {
            bool retorno;
            try
            {
                StreamWriter sw = new StreamWriter(path);
                sw.Write(cadena);
                sw.Close();
                retorno = true;
            }
            catch (DirectoryNotFoundException)
            {
                retorno = false;
            }
            return retorno;
        }

        public static bool Leer(string path,out string cadena)
        {
            bool retorno;
            try
            {
                StreamReader sr = new StreamReader(path);
                cadena = sr.ReadToEnd();
                sr.Close();
                retorno = true;
            }
            catch (DirectoryNotFoundException)
            {
                retorno = false;
                cadena = "";
            }
            return retorno;
        }
    }
}
