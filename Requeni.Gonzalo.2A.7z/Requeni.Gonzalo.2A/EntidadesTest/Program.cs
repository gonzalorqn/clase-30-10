﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Program
    {
        static void Main(string[] args)
        {
            string cad;
            string path;
            path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\hola2.txt";
            if (AdministradorArchivos.Escribir(path, "hola que tal"))
                Console.WriteLine("Se escribio correctamente");
            else
                Console.WriteLine("No se pudo escribir");
            Console.ReadLine();
            if (AdministradorArchivos.Leer(path, out cad))
                Console.WriteLine(cad);
            else
                Console.WriteLine("No se pudo leer");
            Console.ReadLine();


            path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\hola2.txt";

            if (AdministradorArchivos.Escribir(path, "hola que tal"))
                Console.WriteLine("Se escribio correctamente");
            else
                Console.WriteLine("No se pudo escribir");
            Console.ReadLine();
            if (AdministradorArchivos.Leer(path, out cad))
                Console.WriteLine(cad);
            else
                Console.WriteLine("No se pudo leer");
            Console.ReadLine();


            path = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures) + "\\hola2.txt";

            if (AdministradorArchivos.Escribir(path, "hola que tal"))
                Console.WriteLine("Se escribio correctamente");
            else
                Console.WriteLine("No se pudo escribir");
            Console.ReadLine();
            if (AdministradorArchivos.Leer(path, out cad))
                Console.WriteLine(cad);
            else
                Console.WriteLine("No se pudo leer");
            Console.ReadLine();


            //path donde esta el .exe
            path = AppDomain.CurrentDomain.BaseDirectory + "\\hola2.txt";

            if (AdministradorArchivos.Escribir(path, "hola que tal"))
                Console.WriteLine("Se escribio correctamente");
            else
                Console.WriteLine("No se pudo escribir");
            Console.ReadLine();
            if (AdministradorArchivos.Leer(path, out cad))
                Console.WriteLine(cad);
            else
                Console.WriteLine("No se pudo leer");
            Console.ReadLine();
        }
    }
}
